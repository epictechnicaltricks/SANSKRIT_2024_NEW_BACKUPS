package shubhamjit.san.hindi.sanskrit_hindi;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

import shubhamjit.san.hindi.R;


public class LanguageActivity extends  AppCompatActivity  {
	
	
	private boolean language_from = false;
	private double r = 0;
	private double length = 0;
	private String value1 = "";
	private double n = 0;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout nav;
	private LinearLayout back_layout1;
	private LinearLayout layout;
	private LinearLayout toolbar;
	private LinearLayout linear_search;
	private ListView listview;
	private ImageView back;
	private TextView title;
	private ImageView imageview1;
	private EditText edittext_search;
	
	private SharedPreferences data;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.san_language);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		nav = (LinearLayout) findViewById(R.id.nav);
		back_layout1 = (LinearLayout) findViewById(R.id.back_layout1);
		layout = (LinearLayout) findViewById(R.id.layout);
		toolbar = (LinearLayout) findViewById(R.id.toolbar);
		linear_search = (LinearLayout) findViewById(R.id.linear_search);
		listview = (ListView) findViewById(R.id.listview);
		back = (ImageView) findViewById(R.id.back);
		title = (TextView) findViewById(R.id.title);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		edittext_search = (EditText) findViewById(R.id.edittext_search);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});

		try {
			java.io.InputStream inp = getAssets().open("languages.json");
			listmap = new Gson().fromJson(Util.copyFromInputStream(inp), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			listview.setAdapter(new ListviewAdapter(listmap));
		} catch(Exception e) {

		}


		edittext_search.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();

				for(int _repeat17 = 0; _repeat17 < listmap.size(); _repeat17++) {

					if (listmap.get(_repeat17).get("name").toString().toLowerCase(Locale.ROOT).contains(_charSeq.toLowerCase(Locale.ROOT))) {
						listview.scrollListBy(_repeat17);
					}

				}


				/*try {
					java.io.InputStream inp = getAssets().open("languages.json");
					listmap = new Gson().fromJson(Util.copyFromInputStream(inp), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					listview.setAdapter(new ListviewAdapter(listmap));
				} catch(Exception e) {
					 
				}
				length = listmap.size();
				r = length - 1;
				for(int _repeat17 = 0; _repeat17 < (int)(length); _repeat17++) {
					value1 = listmap.get((int)r).get("name").toString();
					if (true) {
						
					}
					else {
						listmap.remove((int)(r));
					}
					r--;
				}
				listview.setAdapter(new ListviewAdapter(listmap));
				((BaseAdapter)listview.getAdapter()).notifyDataSetChanged();
*/			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =LanguageActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		_setCornerRadii(back_layout1, "#80F7F8FC", 40, 40, 0, 0);
		_setCornerRadii(layout, "#F7F8FC", 40, 40, 0, 0);
		linear_search.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
		if (getIntent().hasExtra("type")) {
			if (getIntent().getStringExtra("type").contains("from")) {
				language_from = true;
			}
			if (getIntent().getStringExtra("type").contains("to")) {
				language_from = false;
			}
		}
		try {
			java.io.InputStream inp = getAssets().open("languages.json");
			listmap = new Gson().fromJson(Util.copyFromInputStream(inp), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			listview.setAdapter(new ListviewAdapter(listmap));
		} catch(Exception e) {
			 
		}
		_scrollToSelectedLanguage();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	public void _setCornerRadii (final View _view, final String _color, final double _x1, final double _x2, final double _x3, final double _x4) {
		GradientDrawable gd = new GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadii(new float[] { (int)_x1, (int)_x1, (int)_x2, (int)_x2, (int)_x3, (int)_x3, (int)_x4, (int)_x4 }); 
		_view.setBackground(gd);
	}
	
	
	public void _scrollToSelectedLanguage () {
		n = 0;
		for(int _repeat11 = 0; _repeat11 < (int)(listmap.size()); _repeat11++) {
			if (listmap.get((int)n).containsKey("code")) {
				if (language_from) {
					if (data.contains("lang_from_code")) {
						if (listmap.get((int)n).get("code").toString().equals(data.getString("lang_from_code", ""))) {
							listview.setSelection((int)n);
							break;
						}
						else {
							
						}
					}
				}
				else {
					if (data.contains("lang_to_code")) {
						if (listmap.get((int)n).get("code").toString().equals(data.getString("lang_to_code", ""))) {
							listview.setSelection((int)n);
							break;
						}
						else {
							
						}
					}
				}
			}
			n++;
		}
	}
	
	
	public class ListviewAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public ListviewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.san_language_item, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final TextView lang_name = (TextView) _view.findViewById(R.id.lang_name);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			
			imageview1.setVisibility(View.GONE);
			linear1.setBackgroundColor(Color.TRANSPARENT);
			imageview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
			if (_data.get((int)_position).containsKey("code")) {
				if (language_from) {
					if (listmap.get((int)_position).get("code").toString().equals(data.getString("lang_from_code", ""))) {
						imageview1.setVisibility(View.VISIBLE);
						linear1.setBackgroundColor(0xFFEAEDF6);
					}
				}
				else {
					if (listmap.get((int)_position).get("code").toString().equals(data.getString("lang_to_code", ""))) {
						imageview1.setVisibility(View.VISIBLE);
						linear1.setBackgroundColor(0xFFEAEDF6);
					}
				}
			}
			if (_data.get((int)_position).containsKey("name")) {
				lang_name.setText(listmap.get((int)_position).get("name").toString());
			}
			linear1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View _view) {
					notifyDataSetChanged();
					if (language_from) {
						data.edit().putString("lang_from", listmap.get((int)_position).get("name").toString()).commit();
						data.edit().putString("lang_from_code", listmap.get((int)_position).get("code").toString()).commit();
					}
					else {
						data.edit().putString("lang_to", listmap.get((int)_position).get("name").toString()).commit();
						data.edit().putString("lang_to_code", listmap.get((int)_position).get("code").toString()).commit();
					}
					finish();
				}
			});
			
			return _view;
		}
	}
	

	
}
