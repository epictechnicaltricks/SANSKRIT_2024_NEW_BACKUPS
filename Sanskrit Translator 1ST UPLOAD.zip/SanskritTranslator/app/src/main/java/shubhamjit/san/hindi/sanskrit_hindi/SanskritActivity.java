package shubhamjit.san.hindi.sanskrit_hindi;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import shubhamjit.san.hindi.R;


public class SanskritActivity extends  AppCompatActivity  {
	public static final int REQ_CODE_SPEECH_INPUT = 1;
	private Timer _timer = new Timer();
	
	private String text = "";
	private HashMap<String, Object> params = new HashMap<>();
	private HashMap<String, Object> map = new HashMap<>();
	private boolean bookmark_visible = false;
	private String to_lang = "";
	private String to_lang_code = "";
	private String from_lang_code = "";
	private String from_lang = "";
	private double len = 0;
	
	private ArrayList<HashMap<String, Object>> listmap_bookmarks = new ArrayList<>();
	private ArrayList<String> gs = new ArrayList<>();
	
	private LinearLayout nav;
	private LinearLayout topbar;
	private LinearLayout layout;
	private ImageView btn_bookmarks;
	private TextView tv_title;
	private ImageView btn_give_like;
	private ScrollView vscroll;
	private CardView cardview_bookmark;
	private LinearLayout linear_scroll;
	private CardView cardview;
	private LinearLayout linear_card;
	private LinearLayout linear;
	private LinearLayout linear_translated;
	private LinearLayout linear5;
	private LinearLayout linear9;
	private EditText et_text_translate;
	private LinearLayout linear11;
	private TextView tv_from_lang;
	private ImageView btn_change_lamguage;
	private TextView tv_to_lang;
	private ImageView btn_paste;
	private ImageView btn_clear;
	private TextView tv_translated_text;
	private LinearLayout linear10;
	private ImageView speaker;
	private ImageView btn_copy;
	private ImageView btn_bookmark;
	private LinearLayout linear_bookmarks;
	private LinearLayout linear12;
	private GridView gridview;
	private TextView textview5;
	private ImageView imageview1;
	
	private RequestNetwork api;
	private RequestNetwork.RequestListener _api_request_listener;
	private TimerTask translate_timer;
	private SharedPreferences data;
	private Intent intent = new Intent();
	private ObjectAnimator oa = new ObjectAnimator();
	private Intent tg = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.san_main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		nav = (LinearLayout) findViewById(R.id.nav);
		topbar = (LinearLayout) findViewById(R.id.topbar);
		layout = (LinearLayout) findViewById(R.id.layout);
		btn_bookmarks = (ImageView) findViewById(R.id.btn_bookmarks);
		tv_title = (TextView) findViewById(R.id.tv_title);
		btn_give_like = (ImageView) findViewById(R.id.btn_give_like);
		vscroll = (ScrollView) findViewById(R.id.vscroll);
		cardview_bookmark = (CardView) findViewById(R.id.cardview_bookmark);
		linear_scroll = (LinearLayout) findViewById(R.id.linear_scroll);
		cardview = (CardView) findViewById(R.id.cardview);
		linear_card = (LinearLayout) findViewById(R.id.linear_card);
		linear = (LinearLayout) findViewById(R.id.linear);
		linear_translated = (LinearLayout) findViewById(R.id.linear_translated);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		et_text_translate = (EditText) findViewById(R.id.et_text_translate);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		tv_from_lang = (TextView) findViewById(R.id.tv_from_lang);
		btn_change_lamguage = (ImageView) findViewById(R.id.btn_change_lamguage);
		tv_to_lang = (TextView) findViewById(R.id.tv_to_lang);
		btn_paste = (ImageView) findViewById(R.id.btn_paste);
		btn_clear = (ImageView) findViewById(R.id.btn_clear);
		tv_translated_text = (TextView) findViewById(R.id.tv_translated_text);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		speaker = (ImageView) findViewById(R.id.speaker);
		btn_copy = (ImageView) findViewById(R.id.btn_copy);
		btn_bookmark = (ImageView) findViewById(R.id.btn_bookmark);
		linear_bookmarks = (LinearLayout) findViewById(R.id.linear_bookmarks);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		gridview = (GridView) findViewById(R.id.gridview);
		textview5 = (TextView) findViewById(R.id.textview5);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		api = new RequestNetwork(this);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		btn_bookmarks.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (bookmark_visible) {
					_TransitionManager(nav, 200);
					bookmark_visible = false;
					cardview_bookmark.setVisibility(View.GONE);
				}
				else {
					_TransitionManager(nav, 200);
					bookmark_visible = true;
					cardview_bookmark.setVisibility(View.VISIBLE);
					_hideKeyboard();
				}
			}
		});
		
		btn_give_like.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				tg.setAction(Intent.ACTION_VIEW);
				tg.setData(Uri.parse("https://play.google.com/store/apps/details?id="+getPackageName()));
				startActivity(tg);
			}
		});
		
		et_text_translate.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (bookmark_visible) {
					_TransitionManager(nav, 200);
					bookmark_visible = false;
					cardview_bookmark.setVisibility(View.GONE);
				}
			}
		});
		
		et_text_translate.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				try {
					translate_timer.cancel();
				} catch(Exception e) {
					 
				}
				translate_timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								if (et_text_translate.getText().toString().trim().equals("")) {
									_TransitionManager(nav, 200);
									linear_translated.setVisibility(View.GONE);
								}
								else {
									_TransitionManager(nav, 200);
									bookmark_visible = false;
									cardview_bookmark.setVisibility(View.GONE);
									text = et_text_translate.getText().toString().trim();
									params = new HashMap<>();
									params.put("User-Agent", "Mozilla/5.0");
									api.setParams(params, RequestNetworkController.REQUEST_PARAM);
									try {
										api.startRequestNetwork(RequestNetworkController.GET, "https://translate.googleapis.com/translate_a/single?client=gtx&sl=".concat(data.getString("lang_from_code", "").concat("&tl=".concat(data.getString("lang_to_code", "").concat("&dt=t&q=".concat(java.net.URLEncoder.encode(text, "UTF-8")))))), "a", _api_request_listener);
									} catch(Exception e) {
										_snackbar("An error occurred");
									}
								}
							}
						});
					}
				};
				_timer.schedule(translate_timer, (int)(250));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		tv_from_lang.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.putExtra("type", "from");
				intent.setClass(getApplicationContext(), LanguageActivity.class);
				startActivity(intent);
			}
		});
		
		btn_change_lamguage.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				oa.setTarget(linear5);
				oa.setPropertyName("alpha");
				oa.setFloatValues((float)(0), (float)(1));
				oa.start();
				to_lang = tv_to_lang.getText().toString();
				to_lang_code = data.getString("lang_to_code", "");
				from_lang_code = data.getString("lang_from_code", "");
				from_lang = tv_from_lang.getText().toString();
				data.edit().putString("lang_to", from_lang).commit();
				data.edit().putString("lang_to_code", from_lang_code).commit();
				data.edit().putString("lang_from", to_lang).commit();
				data.edit().putString("lang_from_code", to_lang_code).commit();
				tv_from_lang.setText(data.getString("lang_from", ""));
				tv_to_lang.setText(data.getString("lang_to", ""));
				_TransitionManager(nav, 200);
				bookmark_visible = false;
				cardview_bookmark.setVisibility(View.GONE);
				if (et_text_translate.getText().toString().trim().equals("")) {
					
				}
				else {
					text = et_text_translate.getText().toString().trim();
					params = new HashMap<>();
					params.put("User-Agent", "Mozilla/5.0");
					api.setParams(params, RequestNetworkController.REQUEST_PARAM);
					try {
						api.startRequestNetwork(RequestNetworkController.GET, "https://translate.googleapis.com/translate_a/single?client=gtx&sl=".concat(data.getString("lang_from_code", "").concat("&tl=".concat(data.getString("lang_to_code", "").concat("&dt=t&q=".concat(java.net.URLEncoder.encode(text, "UTF-8")))))), "a", _api_request_listener);
					} catch(Exception e) {
						_snackbar("An error occurred");
					}
				}
			}
		});
		
		tv_to_lang.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.putExtra("type", "to");
				intent.setClass(getApplicationContext(), LanguageActivity.class);
				startActivity(intent);
			}
		});
		
		btn_paste.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
				try {
					et_text_translate.setText(clipboard.getText().toString().trim());
				} catch(Exception e) {
					Util.showToast( "Not copied any text", getApplicationContext());
				}
			}
		});
		
		btn_clear.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				et_text_translate.setText("");
			}
		});
		
		speaker.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent intent = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
				intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
						android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
				intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
				intent.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Speak Now");
				try {
					startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
				}
				catch (ActivityNotFoundException a) {
					Toast.makeText(getApplicationContext(), "There was an error", Toast.LENGTH_SHORT).show(); }
			}
		});
		
		btn_copy.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", tv_translated_text.getText().toString()));
				_snackbar("Copied to clipboard");
			}
		});
		
		btn_bookmark.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				map = new HashMap<>();
				map.put("text", et_text_translate.getText().toString());
				map.put("translate", tv_translated_text.getText().toString());
				listmap_bookmarks.add(map);
				gridview.setAdapter(new GridviewAdapter(listmap_bookmarks));
				_snackbar("Added to bookmarks");
				_save_bookmark_list();
			}
		});
		
		gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				et_text_translate.setText(listmap_bookmarks.get((int)_position).get("text").toString());
				_setCursorPosition(et_text_translate, et_text_translate.getText().toString().length());
			}
		});
		
		gridview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				_TransitionManager(nav, 200);
				listmap_bookmarks.remove((int)(_position));
				gridview.setAdapter(new GridviewAdapter(listmap_bookmarks));
				if (listmap_bookmarks.size() == -1) {
					bookmark_visible = false;
					cardview_bookmark.setVisibility(View.GONE);
				}
				_save_bookmark_list();
				_snackbar("Removed from bookmarks");
				return true;
			}
		});
		
		imageview1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (bookmark_visible) {
					_TransitionManager(nav, 200);
					bookmark_visible = false;
					cardview_bookmark.setVisibility(View.GONE);
				}
				else {
					_TransitionManager(nav, 200);
					bookmark_visible = true;
					cardview_bookmark.setVisibility(View.VISIBLE);
					_hideKeyboard();
				}
			}
		});
		
		_api_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				tv_translated_text.setText("");
				try {
					_TransitionManager(nav, 200);
					linear_translated.setVisibility(View.VISIBLE);
					JSONArray JsonArray1= new JSONArray(_response);
					
					
					JSONArray JsonArray2 = JsonArray1.getJSONArray(0);
					len = JsonArray2.length();
					for(int i= 0; i < (int)(len); i++) {
						JSONArray JsonArray3 = JsonArray2.getJSONArray((int)i);
						tv_translated_text.setText(tv_translated_text.getText().toString().concat(JsonArray3.getString(0)));
					}
				} catch(Exception e) {
					_snackbar("An error occurred");
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				_snackbar("No internet connection");
			}
		};
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =SanskritActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFFF7F8FC);
		}
		;
		_restore_bookmarks_list();
		speaker.setColorFilter(0xFF465A65);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);

		if (_requestCode == REQ_CODE_SPEECH_INPUT) {
			if (null != _data) {
				ArrayList<String> result = _data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
				et_text_translate.setText(result.get(0).trim());
			}
		}
	}

	@Override
	public void onBackPressed() {

		SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
		if(sharedPreferences2.getString("rate","").equals("done"))
		{
			finishAffinity();
		}else {
			cus_rate("https://play.google.com/store/apps/details?id="+getPackageName());
		}



	}
	private void cus_rate(String open_link) {
		final AlertDialog dialog3 = new AlertDialog.Builder(this).create();
		View inflate = getLayoutInflater().inflate(R.layout.rating,null);

		dialog3.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog3.setView(inflate);

		final TextView title = inflate.findViewById(R.id.title_cus_dia);
		final TextView rate = (TextView) inflate.findViewById(R.id.rate);
		final TextView later = (TextView) inflate.findViewById(R.id.later);
				/*TextView done  = (TextView) inflate.findViewById(R.id.done);
TextView close  = (TextView) inflate.findViewById(R.id.close);
final TextView amt = (TextView) inflate.findViewById(R.id.amt);
*/
		final LinearLayout bg = (LinearLayout) inflate.findViewById(R.id.bg);




		dialog3.setCancelable(true);



		later.setOnClickListener(view -> {
			finish();
		});


		rate.setOnClickListener(_view -> {
			if(!open_link.equals("")){

				try {
					Intent in = new Intent();
					in.setAction(Intent.ACTION_VIEW);
					in.setData(Uri.parse(open_link));
					startActivity(in);
					SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
					final SharedPreferences.Editor myEdit = sharedPreferences2.edit();
					myEdit.putString("rate","done");
					myEdit.apply();
				}catch (Exception w)
				{
					Util.showToast("Failed to open",SanskritActivity.this);
					w.printStackTrace();
				}


				//it will rest the drop date after user click the

				// rate us button



				dialog3.dismiss();
			}

		});
		dialog3.show();
	}




	@Override
	public void onStart() {
		super.onStart();

		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
		if (data.contains("lang_from")) {
			tv_from_lang.setText(data.getString("lang_from", ""));
		}
		else {
			tv_from_lang.setText(getResources().getString(R.string.from_lang_text));
			data.edit().putString("lang_from", tv_from_lang.getText().toString()).apply();
			data.edit().putString("lang_from_code", getResources().getString(R.string.from_lang)).apply();
		}
		if (data.contains("lang_to")) {
			tv_to_lang.setText(data.getString("lang_to", ""));
		}
		else {
			//tv_to_lang.setText(Locale.getDefault().getDisplayLanguage());
			tv_to_lang.setText(getResources().getString(R.string.to_lang_text));
			data.edit().putString("lang_to", tv_to_lang.getText().toString()).apply();
		//	data.edit().putString("lang_to_code", Locale.getDefault().getLanguage()).apply();

			data.edit().putString("lang_to_code", getResources().getString(R.string.to_lang)).apply();
		}
		//Util.showToast(Locale.getDefault().getDisplayLanguage(),SanskritActivity.this);
		if (data.contains("lang_from") && data.contains("lang_to")) {
			if (et_text_translate.getText().toString().trim().equals("")) {
				_TransitionManager(nav, 200);
				linear_translated.setVisibility(View.GONE);
			}
			else {
				_TransitionManager(nav, 200);
				bookmark_visible = false;
				cardview_bookmark.setVisibility(View.GONE);
				text = et_text_translate.getText().toString().trim();
				params = new HashMap<>();
				params.put("User-Agent", "Mozilla/5.0");
				api.setParams(params, RequestNetworkController.REQUEST_PARAM);
				try {
					api.startRequestNetwork(RequestNetworkController.GET, "https://translate.googleapis.com/translate_a/single?client=gtx&sl=".concat(data.getString("lang_from_code", "").concat("&tl=".concat(data.getString("lang_to_code", "").concat("&dt=t&q=".concat(java.net.URLEncoder.encode(text, "UTF-8")))))), "a", _api_request_listener);
				} catch(Exception e) {
					_snackbar("An error occurred");
				}
			}
		}
	}
	public void _TransitionManager (final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _snackbar (final String _text) {

		Util.showToast(_text,this);
		/*Util.CustomToast(getApplicationContext(), _text, 0xFFFFFFFF, 19, 0xFF000000, 25, SketchwareUtil.BOTTOM);*/
		/*Snackbar snackbar = Snackbar.make(nav, _text, Snackbar.LENGTH_LONG);
snackbar.setDuration(2000);
snackbar.show();*/
	}
	
	
	public void _hideKeyboard () {
		android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) this.getSystemService(Activity.INPUT_METHOD_SERVICE); 
		//Find the currently focused view, so we can grab the correct window token from it. 

		imm.hideSoftInputFromWindow(et_text_translate.getWindowToken(), 0);
	}
	
	
	public void _save_bookmark_list () {
		data.edit().putString("bookmark", new Gson().toJson(listmap_bookmarks)).commit();
	}
	
	
	public void _restore_bookmarks_list () {
		if (data.contains("bookmark")) {
			listmap_bookmarks = new Gson().fromJson(data.getString("bookmark", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			gridview.setAdapter(new GridviewAdapter(listmap_bookmarks));
		}
	}
	
	
	public void _setCursorPosition (final TextView _textview, final double _position) {
		((EditText)_textview).setSelection((int)_position);
	}
	
	
	public void _setCornerRadii (final View _view, final String _color, final double _x1, final double _x2, final double _x3, final double _x4) {
		GradientDrawable gd = new GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadii(new float[] { (int)_x1, (int)_x1, (int)_x2, (int)_x2, (int)_x3, (int)_x3, (int)_x4, (int)_x4 }); 
		_view.setBackground(gd);
	}
	
	
	public class GridviewAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public GridviewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.san_bookmark_item, null);
			}
			
			final LinearLayout linear = (LinearLayout) _view.findViewById(R.id.linear);
			final CardView cardview1 = (CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
			final TextView tv_text = (TextView) _view.findViewById(R.id.tv_text);
			final TextView tv_translated_text = (TextView) _view.findViewById(R.id.tv_translated_text);
			
			if (_data.get((int)_position).containsKey("text")) {
				tv_text.setText(_data.get((int)_position).get("text").toString());
			}
			if (_data.get((int)_position).containsKey("translate")) {
				tv_translated_text.setText(_data.get((int)_position).get("translate").toString());
			}
			
			return _view;
		}
	}

	public void shareText(View view)
	{
		Util.showToast("Sharing..",SanskritActivity.this);
		Util.share_text(SanskritActivity.this, getResources().getString(R.string.app_name)+" translation\n\n"+tv_translated_text.getText().toString().trim()+"\n\nTranslated from : \n\n"+et_text_translate.getText().toString().trim());
	}

	public void ocr(View view)
	{
		Util.showToast("Coming soon..",SanskritActivity.this);
		//Util.share_text(SanskritActivity.this, getResources().getString(R.string.app_name)+" translation\n\n"+tv_translated_text.getText().toString().trim()+"\n\nTranslated from : \n\n"+et_text_translate.getText().toString().trim());
	}


}
